#1st program
print(9**0.5*5)