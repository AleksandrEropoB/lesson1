#3rd program
print(1234//10%100+5678//10%100)