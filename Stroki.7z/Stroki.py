example = 'Derevo'
print(example[0])
print(example[-1])
print(example[3:6])
print(example[::-1])
print(example[1:6:2])

